result[0] = -c[1];
result[1] = c[0];
