public class Documentation {

    public static void main (String[] args) {

        //! [hello_world]
        System.out.println ("Hello World!");
        //! [hello_world]
    }
}
